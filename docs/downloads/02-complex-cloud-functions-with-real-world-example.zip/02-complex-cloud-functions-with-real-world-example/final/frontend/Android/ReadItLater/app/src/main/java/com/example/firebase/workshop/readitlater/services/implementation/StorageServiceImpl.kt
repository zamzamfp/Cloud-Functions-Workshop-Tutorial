package com.example.firebase.workshop.readitlater.services.implementation

import com.example.firebase.workshop.readitlater.model.Article
import com.example.firebase.workshop.readitlater.services.AccountService
import com.example.firebase.workshop.readitlater.services.StorageService
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.ktx.dataObjects
import com.google.firebase.firestore.ktx.toObject
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

class StorageServiceImpl @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val auth: AccountService
) : StorageService {

    override val articles: Flow<List<Article>>
        get() =
            auth.currentUser.flatMapLatest { user ->
                firestore
                    .collection(ARTICLE_COLLECTION)
                    .whereEqualTo(USER_ID, user.id)
                    .dataObjects()
            }

    override suspend fun getArticle(articleId: String): Article? =
        firestore
            .collection(ARTICLE_COLLECTION)
            .document(articleId)
            .get()
            .await()
            .toObject()

    override suspend fun save(article: Article) {
        val editedArticle = article.copy(userId = auth.currentUserId)
        firestore
            .collection(ARTICLE_COLLECTION)
            .add(editedArticle)
            .await()
            .id
    }

    override suspend fun update(article: Article) {
        firestore
            .collection(ARTICLE_COLLECTION)
            .document(article.id)
            .set(article, SetOptions.merge())
            .await()
    }

    override suspend fun delete(articleId: String) {
        firestore
            .collection(ARTICLE_COLLECTION)
            .document(articleId)
            .delete()
            .await()
    }

    companion object {
        private const val USER_ID = "userId"
        private const val ARTICLE_COLLECTION = "articles"
    }
}

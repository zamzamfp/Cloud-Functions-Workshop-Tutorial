import * as functions from "firebase-functions";
import * as admin from "firebase-admin";

import * as parser from "@postlight/mercury-parser";
import { readingTime } from "reading-time-estimator";
import { stripHtml } from "string-strip-html";

// ------------------ Firebase initialisation ------------------

admin.initializeApp();

// ------------------ Hello World ------------------

export const helloWorld = functions.https.onRequest((_request, response) => {
  functions.logger.info("Hello logs!", {structuredData: true});
  response.send("Hello from Firebase!");
});


// ------------------ Fetch readable HTML ------------------

// define a type for the article document
interface ArticleDocument {
  author?: string;
  // dateAdded?: Timestamp;
  datePublished: string;
  excerpt?: string;
  imageUrl?: string;
  isRead?: boolean;
  notes?: string;
  siteName?: string;
  status?: string;
  title?: string;
  url: string;
  userId?: string;
  wordCount: number;
  readingTime: number;
  readableHTML: string;
}

export const updateArticleMetadata = functions.firestore.document("articles/{documentId}").onCreate(async (documentSnapshot) => {

  const articleDocument = documentSnapshot.data() as ArticleDocument;
  
  // get the url of the article
  const url = articleDocument.url;
  
  functions.logger.log(`Updating metadata for ${url}`);

  // parse the url using the Mercury Parser to get the metadata and readable content
  const metadata = await parser.parse(url);

  functions.logger.log(`Metadata for ${url} is ${JSON.stringify(metadata)}`);

  if (!articleDocument.author && metadata.author) {
    articleDocument.author = metadata.author;
  }

  if (!articleDocument.title && metadata.title) {
    articleDocument.title = metadata.title;
  }

  if (!articleDocument.datePublished && metadata.date_published) {
    articleDocument.datePublished = metadata.date_published;
  }

  if (!articleDocument.imageUrl && metadata.lead_image_url) {
    articleDocument.imageUrl = metadata.lead_image_url;
  }

  if (!articleDocument.siteName && metadata.domain) {
    articleDocument.siteName = metadata.domain;
  }

  if (!articleDocument.excerpt && metadata.excerpt) {
    articleDocument.excerpt = metadata.excerpt;
  }

  // compute the reading time in minutes using read-time-estimate
  if (!articleDocument.readingTime && metadata.content) {
    const strippedContent = stripHtml(metadata.content).result;

    const readTime = readingTime(strippedContent);
    articleDocument.readingTime = readTime.minutes;

    // update the wordcount based on read-time-estimate if it is not already present or empty
    if (!articleDocument.wordCount) {
      articleDocument.wordCount = readTime.words;
    }
  }

  if (!articleDocument.readableHTML && metadata.content) {
    articleDocument.readableHTML = metadata.content;
  }

  // update the document in Firestore
  // the following line works fine until firebase-admin v10.3.0, but yields a comppile error starting with v11.0.0:
  // const articleDocument: ArticleDocument
  // Argument of type 'ArticleDocument' is not assignable to parameter of type '{ [x: string]: any; } & AddPrefixToKeys<string, any>'.
  //   Type 'ArticleDocument' is not assignable to type 'AddPrefixToKeys<string, any>'.
  //     Index signature for type '`${string}.${string}`' is missing in type 'ArticleDocument'.ts(2345)
  // documentSnapshot.ref.update(articleDocument);

  // this line works fine with all versions
  return documentSnapshot.ref.set(articleDocument, {merge: true});
});
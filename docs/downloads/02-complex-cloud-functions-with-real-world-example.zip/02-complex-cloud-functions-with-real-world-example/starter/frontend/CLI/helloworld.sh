#!/bin/bash

curl -X POST -H "Content-Type:application/json" \
 -H "X-MyHeader: 123" \
 http://127.0.0.1:5001/peterfriese-cf-workshop/us-central1/helloWorld \
 -d '{"text":"something"}'
//
// ColorExtraction.swift
// ReadItLater
//
// Created by Peter Friese on 15.03.23.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// From https://stackoverflow.com/questions/56586055/how-to-get-rgb-components-from-color-in-swiftui

import SwiftUI

#if os(macOS)
import AppKit
//typealias UINSColor = NSColor
#else
import UIKit
//typealias UINSColor = UIColor
#endif

extension UINSColor {
    var components: (red: CGFloat, green: CGFloat, blue: CGFloat, opacity: CGFloat) {
        var r: CGFloat = 0
        var g: CGFloat = 0
        var b: CGFloat = 0
        var o: CGFloat = 0
#if os(macOS)
        usingColorSpace(.deviceRGB)!.getRed(&r, green: &g, blue: &b, alpha: &o)
#else
        guard getRed(&r, green: &g, blue: &b, alpha: &o) else {
            // You can handle the failure here as you want
            return (0, 0, 0, 0)
        }
#endif
        return (r, g, b, o)
    }
    
    // From https://stackoverflow.com/questions/26341008/how-to-convert-uicolor-to-hex-and-display-in-nslog
    var hexString: String {
        let (red, green, blue, _) = components
        let hexString = String.init(format: "#%02lX%02lX%02lX", lroundf(Float(red * 255)), lroundf(Float(green * 255)), lroundf(Float(blue * 255)))
        return hexString
    }
    
    var hexPair: (light: String, dark: String) {
        var light: String!
        var dark: String!
        withColorScheme(dark: false) {
            light = self.hexString
        }
        withColorScheme(dark: true) {
            dark = self.hexString
        }
        return (light, dark)
    }
}

private func withColorScheme(dark: Bool /* otherwise light */, block: () -> Void) {
#if os(macOS)
    NSAppearance(named: dark ? .darkAqua : .aqua)!.performAsCurrentDrawingAppearance {
        block()
    }
#else
    UITraitCollection(userInterfaceStyle: dark ? .dark : .light).performAsCurrent {
        block()
    }
#endif
}

//
// ArticleListRowView.swift
// ReadItLater
//
// Created by Peter Friese on 15.03.23.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import SwiftUI

struct ArticleListRowView: View {
    var article: Article
    
    var body: some View {
        HStack(alignment: .top, spacing: 4) {
            Circle()
                .foregroundColor(Color.blue)
                .frame(width: 10, height: 10)
                .padding([.top, .leading], 6)
                .opacity(article.isRead ?? false ? 0 : 1)
            VStack(alignment: .leading, spacing: 4) {
                HStack(alignment: .top) {
                    Text(article.siteName)
                        .font(.subheadline)
                    Spacer()
                    Text(article.dateAddedString)
                        .font(.subheadline)
                }
                HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(article.title)
                            .font(.body)
                            .bold()
                        if let excerpt = article.excerpt {
                            Text(excerpt)
                                .font(.footnote)
                                .lineLimit(2)
                        }
                        Text("\(article.author ?? "") • \(article.readingTime ?? 0) mins")
                            .font(.footnote)
                    }
                    Spacer()
                    heroImage()
                }
            }
        }
    }
    
    func heroImage() -> some View {
        VStack(alignment: .center) {
            if let imageUrl = article.imageUrl {
                AsyncImage(url: URL(string: imageUrl)) { phase in
                    if let image = phase.image {
                        image
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                    } else if phase.error != nil {
                        Color.red.frame(width: 128, height: 128)
                    } else {
                        ProgressView()
                    }
                }
                .frame(width: 50, height: 50, alignment: .center)
                .cornerRadius(8.0)
            }
            else {
                Image(systemName: "scribble.variable")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .padding()
                    .frame(width: 50, height: 50, alignment: .center)
                    .background(Color.accentColor)
                    .cornerRadius(8.0)
            }
        }
    }
}

struct ArticleListRowView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            List {
                ArticleListRowView(article: Article.samples[0])
                ArticleListRowView(article: Article.samples[1])
                ArticleListRowView(article: Article.samples[2])
            }
            .listStyle(.plain)
            .navigationTitle("Articles")
        }
    }
}

//
// AddArticleView.swift
// ReadItLater
//
// Created by Peter Friese on 15.03.23.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import SwiftUI
import Combine

struct AddArticleView: View {
    @Environment(\.dismiss) var dismiss
    
    @ObservedObject
    private var viewModel = AddArticleViewModel()
    
    private func addArticle() {
        viewModel.addArticle()
        dismiss()
    }
    
    private func cancel() {
        dismiss()
    }
    
    var body: some View {
        NavigationStack {
            List {
                Section(header: Text("URL")) {
                    TextField("Required", text: $viewModel.url, axis: .vertical)
                        .lineLimit(3)
                }
                Section(header: Text("Title")) {
                    TextField("Optional", text: $viewModel.title, axis: .vertical)
                        .lineLimit(3)
                }
                Section(header: Text("Site")) {
                    TextField("Optional", text: $viewModel.siteName, axis: .vertical)
                }
                Section(header: Text("Author")) {
                    TextField("Optional", text: $viewModel.author, axis: .vertical)
                        .lineLimit(3)
                }
                Section(header: Text("Excerpt")) {
                    TextField("Optional", text: $viewModel.description, axis: .vertical)
                        .lineLimit(3)
                }
                Section(header: Text("Notes")) {
                    TextField("Optional", text: $viewModel.notes, axis: .vertical)
                        .lineLimit(5)
                }
            }
            .listStyle(.plain)
            .navigationTitle("Add Link")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(action: cancel) {
                        Text("Cancel")
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(action: addArticle) {
                        Text("Add")
                    }
                }
            }
        }
    }
}

struct AddArticleView_Previews: PreviewProvider {
    static var previews: some View {
        Text("Dummy")
            .sheet(isPresented: .constant(true)) {
                AddArticleView()
            }
    }
}

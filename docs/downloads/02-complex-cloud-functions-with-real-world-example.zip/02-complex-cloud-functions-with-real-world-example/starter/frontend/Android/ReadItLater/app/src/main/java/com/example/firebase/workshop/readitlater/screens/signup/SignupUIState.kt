package com.example.firebase.workshop.readitlater.screens.signup

data class SignupUIState(
    val email: String = "",
    val password: String = "",
    val repeatPassword: String = ""
)

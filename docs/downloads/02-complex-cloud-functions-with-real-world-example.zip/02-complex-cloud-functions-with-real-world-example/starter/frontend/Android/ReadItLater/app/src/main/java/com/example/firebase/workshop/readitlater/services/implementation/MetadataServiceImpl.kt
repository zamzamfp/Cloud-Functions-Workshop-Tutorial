package com.example.firebase.workshop.readitlater.services.implementation

import com.example.firebase.workshop.readitlater.model.ArticleMetadata
import com.example.firebase.workshop.readitlater.services.MetadataService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import javax.inject.Inject

class MetadataServiceImpl @Inject constructor() : MetadataService {
    override suspend fun getMetadata(url: String): ArticleMetadata {
        val document = withContext(Dispatchers.IO) {
            Jsoup.connect(url).get()
        }

        val title = document.title()
        val imageUrl = document.select("meta[property=og:image]").attr("content")

        val metaUrl = document.select("meta[property=og:url]").attr("content")
        val siteName = document.select("meta[property=og:siteName]").attr("content")
        val description = document.select("meta[property=og:description]").attr("content")
        val metaAuthor = document.select("meta[property=og:bookAuthor]").attr("content")

        return ArticleMetadata(
            url = url,
            metaAuthor = metaAuthor,
            metaDescription = description,
            metaImage = imageUrl,
            metaTitle = title,
            metaUrl = metaUrl,
            siteName = siteName,
            text = ""
        )
    }
}
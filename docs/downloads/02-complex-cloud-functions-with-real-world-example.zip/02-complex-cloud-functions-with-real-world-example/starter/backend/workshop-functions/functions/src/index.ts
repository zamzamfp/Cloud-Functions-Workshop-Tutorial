import * as functions from "firebase-functions";
import * as admin from "firebase-admin";

// ------------------ Firebase initialisation ------------------

admin.initializeApp();

// ------------------ Hello World ------------------

export const helloWorld = functions.https.onRequest((_request, response) => {
  functions.logger.info("Hello logs!", {structuredData: true});
  response.send("Hello from Firebase!");
});


// ------------------ Fetch readable HTML ------------------

// define a type for the article document
interface ArticleDocument {
  author?: string;
  // dateAdded?: Timestamp;
  datePublished: string;
  excerpt?: string;
  imageUrl?: string;
  isRead?: boolean;
  notes?: string;
  siteName?: string;
  status?: string;
  title?: string;
  url: string;
  userId?: string;
  wordCount: number;
  readingTime: number;
  readableHTML: string;
}

// TODO: Implement a function named `updateArticleMetadata` to fetch the readable HTML for an article whenever a document is written to the `articles` collection.
// The function should use the Mercury Parser to fetch the readable HTML and write it to the `readableHTML` field of the document.
// The function should also use the `reading-time-estimator` package to compute the reading time in minutes and write it to the `readingTime` field of the document.
package com.example.firebase.workshop.readitlater.screens.settings

import com.example.firebase.workshop.readitlater.ARTICLES_SCREEN
import com.example.firebase.workshop.readitlater.LOGIN_SCREEN
import com.example.firebase.workshop.readitlater.SIGN_UP_SCREEN
import com.example.firebase.workshop.readitlater.common.ReadItLaterViewModel
import com.example.firebase.workshop.readitlater.services.AccountService
import com.example.firebase.workshop.readitlater.services.StorageService
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.map
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val accountService: AccountService,
    private val storageService: StorageService
) : ReadItLaterViewModel() {
    val uiState = accountService.currentUser.map { SettingsUIState(it.isAnonymous) }

    fun onLoginClick(openScreen: (String) -> Unit) = openScreen(LOGIN_SCREEN)

    fun onSignUpClick(openScreen: (String) -> Unit) = openScreen(SIGN_UP_SCREEN)

    fun onSignOutClick(restartApp: (String) -> Unit) {
        launchCatching {
            accountService.signOut()
            restartApp(ARTICLES_SCREEN)
        }
    }

    fun onDeleteMyAccountClick(restartApp: (String) -> Unit) {
        launchCatching {
            accountService.deleteAccount()
            restartApp(ARTICLES_SCREEN)
        }
    }
}

package com.example.firebase.workshop.readitlater.screens.list

import androidx.lifecycle.ViewModel
import com.example.firebase.workshop.readitlater.ADD_ARTICLE_SCREEN
import com.example.firebase.workshop.readitlater.ARTICLE_ID
import com.example.firebase.workshop.readitlater.READ_ARTICLE_SCREEN
import com.example.firebase.workshop.readitlater.SETTINGS_SCREEN
import com.example.firebase.workshop.readitlater.model.Article
import com.example.firebase.workshop.readitlater.services.StorageService
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class ArticlesScreenViewModel @Inject constructor(
    private val storageService: StorageService,
): ViewModel() {

    val articles = storageService.articles

    fun onAddArticleClick(openScreen: (String) -> Unit) = openScreen(ADD_ARTICLE_SCREEN)

    fun onEditArticleClick(openScreen: (String) -> Unit, article: Article) = openScreen("$ADD_ARTICLE_SCREEN?$ARTICLE_ID={${article.id}}")

    fun onReadArticleClick(openScreen: (String) -> Unit, article: Article) = openScreen("$READ_ARTICLE_SCREEN?$ARTICLE_ID={${article.id}}")

    fun onSettingsClick(openScreen: (String) -> Unit) = openScreen(SETTINGS_SCREEN)

}
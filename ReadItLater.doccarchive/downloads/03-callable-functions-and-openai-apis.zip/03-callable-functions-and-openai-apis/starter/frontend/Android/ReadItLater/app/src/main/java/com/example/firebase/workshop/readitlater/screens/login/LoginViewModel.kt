package com.example.firebase.workshop.readitlater.screens.login

import androidx.compose.runtime.mutableStateOf
import com.example.firebase.workshop.readitlater.LOGIN_SCREEN
import com.example.firebase.workshop.readitlater.R
import com.example.firebase.workshop.readitlater.SETTINGS_SCREEN
import com.example.firebase.workshop.readitlater.common.ReadItLaterViewModel
import com.example.firebase.workshop.readitlater.common.ext.isValidEmail
import com.example.firebase.workshop.readitlater.common.snackbar.SnackbarManager
import com.example.firebase.workshop.readitlater.services.AccountService
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class LoginViewModel @Inject constructor(
    private val accountService: AccountService,
) : ReadItLaterViewModel() {
    var uiState = mutableStateOf(LoginUIState())
        private set

    private val email
        get() = uiState.value.email
    private val password
        get() = uiState.value.password

    fun onEmailChange(newValue: String) {
        uiState.value = uiState.value.copy(email = newValue)
    }

    fun onPasswordChange(newValue: String) {
        uiState.value = uiState.value.copy(password = newValue)
    }

    fun onSignInClick(openAndPopUp: (String, String) -> Unit) {
        if (!email.isValidEmail()) {
            SnackbarManager.showMessage(R.string.email_error)
            return
        }

        if (password.isBlank()) {
            SnackbarManager.showMessage(R.string.empty_password_error)
            return
        }

        launchCatching {
            accountService.authenticate(email, password)
            openAndPopUp(SETTINGS_SCREEN, LOGIN_SCREEN)
        }
    }

    fun onForgotPasswordClick() {
        if (!email.isValidEmail()) {
            SnackbarManager.showMessage(R.string.email_error)
            return
        }

        launchCatching {
            accountService.sendRecoveryEmail(email)
            SnackbarManager.showMessage(R.string.recovery_email_sent)
        }
    }
}

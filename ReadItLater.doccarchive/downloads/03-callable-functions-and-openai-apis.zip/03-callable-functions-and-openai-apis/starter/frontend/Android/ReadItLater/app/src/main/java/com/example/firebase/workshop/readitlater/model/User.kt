package com.example.firebase.workshop.readitlater.model

data class User(
    val id: String = "",
    val isAnonymous: Boolean = true
)
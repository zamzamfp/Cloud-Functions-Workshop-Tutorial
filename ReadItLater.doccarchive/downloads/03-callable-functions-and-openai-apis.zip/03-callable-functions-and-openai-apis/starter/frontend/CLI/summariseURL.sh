#!/bin/bash

# print an error if the first argument is not passed
if [ -z "$1" ]
  then
    echo "No URL supplied. Please pass the URL to summarise as the first argument. Example: ./summariseURL.sh https://peterfriese.dev/posts/combine-vs-async/"
    exit 1
fi

# pass the first argument to the script as the URL to summarise
curl -X GET \
    http://localhost:5001/peterfriese-cf-workshop/us-central1/summariseURL?url=$1
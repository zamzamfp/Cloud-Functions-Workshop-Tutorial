//
// ArticlesRepository.swift
// ReadItLater
//
// Created by Peter Friese on 15.03.23.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import Foundation
import Factory
import FirebaseFirestore
import FirebaseFirestoreSwift
import os
import FirebaseAuth

public class ArticleRepository: ObservableObject {
    // MARK: - Dependencies
    @Injected(\.firestore) var db: Firestore
    
    // MARK: - Publishers
    @Published
    public var articles = [Article]()
    @Published
    public var user: User? = Auth.auth().currentUser
    
    init() {
        Auth.auth().addStateDidChangeListener { [weak self] (auth, user) in
            // Update the currentUser property whenever the authentication state changes
            self?.user = user
            // TODO: Not sure this is the best way to do this, but it fixed the issue of user not being updated here after logging in
            self?.unsubscribe()
            self?.subscribe()
        }
    }
    // MARK: - Private attributes
    private var listenerRegistration: ListenerRegistration?
    let logger = Logger(subsystem: "com.example.firebase.workshop.ReadItLater", category: "persistence")
    
    deinit {
        unsubscribe()
    }
    
    private func unsubscribe() {
        if listenerRegistration != nil {
            listenerRegistration?.remove()
            listenerRegistration = nil
        }
    }
    
    public func subscribe() {
        if listenerRegistration == nil {
            
            let query = db.collection("articles")
                .whereField("userId", isEqualTo: user?.uid ?? "")
            
            listenerRegistration = query.order(by: "dateAdded", descending: true)
                .addSnapshotListener { [weak self] (querySnapshot, error) in
                    guard let documents = querySnapshot?.documents else {
                        self?.logger.debug("No documents")
                        return
                    }
                    
                    self?.logger.debug("Mapping \(documents.count) documents")
                    self?.articles = documents.compactMap { queryDocumentSnapshot in
                        do {
                            return try queryDocumentSnapshot.data(as: Article.self)
                        } catch {
                            print(error)
                            return nil
                        }
                    }
                }
        }
    }
    
    public func addArticle(_ article: Article) {
        do {
            var userArticle = article
            userArticle.userId = user?.uid
            logger.debug("Adding article '\(userArticle.title)' for user \(userArticle.userId ?? "")")
            let _ = try db.collection("articles").addDocument(from: userArticle)
        }
        catch {
            logger.error("Error: \(error.localizedDescription)")
        }
    }
    
    public func toggleReadStatus(_ article: Article) {
        updateReadStatus(article, isRead: !(article.isRead ?? false))
    }
    
    private func updateReadStatus(_ article: Article, isRead: Bool) {
        if let documentID = article.id {
            var updateArticle = article
            updateArticle.isRead = isRead
            do {
                try db.collection("articles").document(documentID).setData(from: updateArticle)
            }
            catch {
                print(error)
            }
        }
    }
    
    public func updateArticle(_ article: Article) {
        if let documentId = article.id {
            do {
                try db.collection("articles").document(documentId).setData(from: article)
            }
            catch {
                self.logger.debug("Unable to update document \(documentId): \(error.localizedDescription)")
            }
        }
    }
    
    public func removeArticle(_ article: Article) {
        if let articleID = article.id {
            db.collection("articles").document(articleID).delete() { error in
                if let error = error {
                    self.logger.debug("Unable to remove document \(error.localizedDescription)")
                }
            }
        }
    }
    
}

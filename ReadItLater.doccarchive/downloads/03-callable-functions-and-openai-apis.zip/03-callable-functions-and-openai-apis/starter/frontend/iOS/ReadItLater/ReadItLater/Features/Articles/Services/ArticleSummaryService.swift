//
// ArticleSummaryService.swift
// ReadItLater
//
// Created by Peter Friese on 15.03.23.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import Foundation
import Factory
import FirebaseFunctions
import os

public class ArticleSummaryService {
    // TODO: (1) Inject Cloud Functions instance
    // TODO: (2) Instantiate HTTPS Callable for the `summariseURLCallable` function
    let logger = Logger(subsystem: "com.example.firebase.workshop.ReadItLater", category: "summary")
    
    public func summariseURL(url urlString: String) async -> String {
        logger.debug("Summarising URL")
        
        do {
            // TODO: (3) Call HTTPS Callable Function "summariseURLCallable"
            return "TODO"
        }
        catch {
            logger.error("\(error.localizedDescription)")
            return ""
        }
    }
}


package com.example.firebase.workshop.readitlater.services.implementation

import com.example.firebase.workshop.readitlater.services.ArticleSummaryService
import com.google.firebase.functions.FirebaseFunctions
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

class ArticleSummaryServiceImpl @Inject constructor(
    private val functions: FirebaseFunctions,
) : ArticleSummaryService {

    override suspend fun summariseURL(url: String): String {
        val result = functions
            .getHttpsCallable("summariseURLCallable")
            .call(url)
            .await()
        return result.data as String
    }
}

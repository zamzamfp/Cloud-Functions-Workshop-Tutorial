import * as functions from "firebase-functions";
import * as admin from "firebase-admin";
import { defineString } from "firebase-functions/params";

import { Configuration, OpenAIApi } from "openai";
const openAIAPIKey = defineString('OPENAI_API_KEY');

import * as parser from "@postlight/mercury-parser";
import { readingTime } from "reading-time-estimator";
import { stripHtml } from "string-strip-html";

// ------------------ Firebase initialisation ------------------

admin.initializeApp();

// ------------------ Hello World ------------------

export const helloWorld = functions.https.onRequest((_request, response) => {
  functions.logger.info("Hello logs!", {structuredData: true});
  response.send("Hello from Firebase!");
});

// ------------------ Greet User ------------------

export const greetUser = functions.https.onRequest((request, response) => {
  const name = request.query.name;
  response.json({message: `Hi ${name}! from Cloud Functions`});
});

// ------------------ Summarise URL ------------------


// TODO: (1) initialise OpenAI SDK
const configuration = new Configuration({
  apiKey: `${openAIAPIKey.value()}`
});
const openai = new OpenAIApi(configuration);

// TODO: (2) Make a summarise function that gets a url as an input and returns the first result that it gets from openAI as a string as an output; use the examples in OpenAI website as an inspiration
async function summarise(url: string) {
  const model = "text-davinci-001";
  functions.logger.log(`Summarising ${url} using ${model}`);

  const completion = await openai.createCompletion({
    model: model,
    prompt: `Summarize this article: ${url}`,
    temperature: 0,
    max_tokens: 256,
    top_p: 1,
    frequency_penalty: 0,
    presence_penalty: 0,
  });

  const summary = completion.data.choices[0].text;

  if (summary) {
    return summary.trim();
  }
  else {
    return "No summary available";
  }
}

// TODO: (3) Add the HTTPS summarizeUrl function that calls the OpenAI api to call the
export const summariseURL = functions.https.onRequest(async (request, response) => {
  const url = request.query.url as string;
  functions.logger.log(`Summarising URL: ${url}`);
  const summary = await summarise(url);
  functions.logger.log(`${summary}`);
  response.status(200).send(summary);
});

// TODO: (4) Now make summarizeUrl function callable
export const summariseURLCallable = functions.region("europe-west1").https.onCall(async (data) => {
  functions.logger.log(`${data}`);
  const url = data;
  const summary = await summarise(url);
  functions.logger.log(`${summary}`);
  return summary;
});

export const askMarv = functions.https.onRequest(async (request, response) => {
  const question = request.query.question as string;
  functions.logger.log(`Asking Marv ${question}`);
  const marvResponse = await marvTheSarcasticBot(question);
  functions.logger.log(`${marvResponse}`);
  response.status(200).send(marvResponse);
});


async function marvTheSarcasticBot(question: string) {
  const model = "text-davinci-003";
  functions.logger.log(`Marv ${question} using ${model}`);

  const response = await openai.createCompletion({
    model: model,
    prompt: `Marv is a chatbot that reluctantly answers questions with sarcastic responses:\n\nYou: How many pounds are in a kilogram?\nMarv: This again? There are 2.2 pounds in a kilogram. Please make a note of this.\nYou: What does HTML stand for?\nMarv: Was Google too busy? Hypertext Markup Language. The T is for try to ask better questions in the future.\nYou: When did the first airplane fly?\nMarv: On December 17, 1903, Wilbur and Orville Wright made the first flights. I wish they’d come and take me away.\nYou: What is the meaning of life?\nMarv: I’m not sure. I’ll ask my friend Google.\nYou: ${question}\nMarv:`,
    temperature: 0.5,
    max_tokens: 60,
    top_p: 0.3,
    frequency_penalty: 0.5,
    presence_penalty: 0.0,
  });

  functions.logger.log(`Marv answer ${response}`);

  const marvResponse = response.data.choices[0].text;

  functions.logger.log(`Marv answer 0 ${marvResponse}`);

  if (marvResponse) {
    return marvResponse.trim();
  }
  else {
    return "No marvResponse available";
  }
}

// define a type for the article document
interface ArticleDocument {
  author?: string;
  // dateAdded?: Timestamp;
  datePublished: string;
  excerpt?: string;
  imageUrl?: string;
  isRead?: boolean;
  notes?: string;
  siteName?: string;
  status?: string;
  title?: string;
  url: string;
  userId?: string;
  wordCount: number;
  readingTime: number;
  readableHTML: string;
}

export const updateArticleMetadata = functions.firestore.document("articles/{documentId}").onCreate(async (documentSnapshot) => {
  
  // get the url of the article
  const url = documentSnapshot.data().url;

  functions.logger.log(`Updating metadata for ${url}`);

  // parse the url using the Mercury Parser to get the metadata and readable content
  const metadata = await parser.parse(url);

  functions.logger.log(`Metadata for ${url} is ${JSON.stringify(metadata)}`);

  // only write metadata for fields that are not already present or empty
  const articleDocument = documentSnapshot.data() as ArticleDocument;

  if (!articleDocument.author && metadata.author) {
    articleDocument.author = metadata.author;
  }

  if (!articleDocument.title && metadata.title) {
    articleDocument.title = metadata.title;
  }

  if (!articleDocument.datePublished && metadata.date_published) {
    articleDocument.datePublished = metadata.date_published;
  }

  if (!articleDocument.imageUrl && metadata.lead_image_url) {
    articleDocument.imageUrl = metadata.lead_image_url;
  }

  if (!articleDocument.siteName && metadata.domain) {
    articleDocument.siteName = metadata.domain;
  }

  if (!articleDocument.excerpt && metadata.excerpt) {
    articleDocument.excerpt = metadata.excerpt;
  }

  // compute the reading time in minutes using read-time-estimate
  if (!articleDocument.readingTime && metadata.content) {
    const strippedContent = stripHtml(metadata.content).result;

    const readTime = readingTime(strippedContent);
    articleDocument.readingTime = readTime.minutes;

    // update the wordcount based on read-time-estimate if it is not already present or empty
    if (!articleDocument.wordCount) {
      articleDocument.wordCount = readTime.words;
    }
  }

  if (!articleDocument.readableHTML && metadata.content) {
    articleDocument.readableHTML = metadata.content;
  }

  // update the document in Firestore
  // the following line works fine until firebase-admin v10.3.0, but yields a comppile error starting with v11.0.0:
  // const articleDocument: ArticleDocument
  // Argument of type 'ArticleDocument' is not assignable to parameter of type '{ [x: string]: any; } & AddPrefixToKeys<string, any>'.
  //   Type 'ArticleDocument' is not assignable to type 'AddPrefixToKeys<string, any>'.
  //     Index signature for type '`${string}.${string}`' is missing in type 'ArticleDocument'.ts(2345)
  // documentSnapshot.ref.update(articleDocument);

  // this line works fine with all versions
  return documentSnapshot.ref.set(articleDocument, {merge: true});
});

// ------------------ Pub/Sub - Schedule Mail Sending ------------------

export const scheduleMailSending = functions.pubsub.schedule('every 2 minutes').onRun(async (context) => {

// TODO: Fill in this functions


});
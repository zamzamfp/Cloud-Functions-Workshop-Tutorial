//
// Article.swift
// ReadItLater
//
// Created by Peter Friese on 15.03.23.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import Foundation
import FirebaseFirestoreSwift

public struct Article: Identifiable, Equatable, Hashable, Codable {
    @DocumentID
    public var id: String?
    
    public var title: String
    public var author: String?
    public var readingTime: Int?
    public var url: String
    public var imageUrl: String?
    public var siteName: String
    public var dateAdded: Date
    public var excerpt: String?
    public var notes: String?
    public var isRead: Bool? = false
    public var isStarred: Bool? = false
    public var userId: String?
    public var readableHTML: String? = nil
}

public extension Article {
    func dateAsString(date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.locale = Locale.current
        return formatter.string(from: date)
    }
    
    var dateAddedString: String {
        return dateAsString(date: dateAdded)
    }
}


public extension Article {
    static var samples = [
        Article(title: "Aubergine Parmigiana Recipe",
                author: "The Guardian",
                readingTime: 4,
                url: "https://theguardian.com",
                siteName: "The Guardian",
                dateAdded: Date(),
                excerpt: "This aubergine parmigiana recipe makes a great vegetarian dinner, with layers of veg, tomatoes, and parmesan.",
                notes: "Delicious!",
                isRead: false
               ),
        Article(title: "We Recommend Material Design Components",
                author: "Nick Butcher",
                readingTime: 4,
                url: "https://medium.com",
                siteName: "Android Developers",
                dateAdded: Date(),
                excerpt: "Here's why",
                notes: "Superb article, must read.",
                isRead: false
               ),
        Article(title: "Adding Data to Firestore from a SwiftUI app",
                author: "Peter Friese",
                readingTime: 6,
                url: "https://peterfriese.dev/swiftui-firebase-add-data/",
                siteName: "peterfriese.dev",
                dateAdded: Date(),
                excerpt: "Learn how to write data to Firestore from a SwiftUI Application",
                notes: "Superb article, must read.",
                isRead: true
               ),
        Article(title: "SwiftUI: Mapping Firestore Documents using Swift Codable",
                author: "Peter Friese",
                readingTime: 11,
                url: "https://peterfriese.dev/swiftui-firebase-codable/",
                siteName: "peterfriese.dev",
                dateAdded: Date(),
                excerpt: "Learn how to easily map Firestore data in Swift",
                notes: "This guy writes good stuff!"
               ),
        Article(title: "SwiftUI: Fetching Data from Firestore in Real Time",
                author: "Peter Friese",
                readingTime: 15,
                url: "https://peterfriese.dev/swiftui-firebase-fetch-data/",
                siteName: "peterfriese.dev",
                dateAdded: Date(),
                excerpt: "Learn how to fetch data from Firestore in a SwiftUI Application",
                notes: "Good stuff, really"
               ),
        Article(title: "Sign in with Apple using SwiftUI and Firebase",
                author: "Peter Friese",
                readingTime: 2,
                url: "https://peterfriese.dev/replicating-reminder-swiftui-firebase-part3/",
                siteName: "peterfriese.dev",
                dateAdded: Date(),
                excerpt: "Learn how to add Sign in with Apple to a to-do list application built using SwiftUI and Firebase",
                notes: "Nice!",
                isStarred: true
               )
    ]
}


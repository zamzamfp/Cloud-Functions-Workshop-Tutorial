//
// ArticlesListViewModel.swift
// ReadItLater
//
// Created by Peter Friese on 15.03.23.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import Foundation
import Combine
import Factory
import FirebaseAuth

class ArticlesListViewModel: ObservableObject {
    // MARK: - Dependencies
    @Injected(\.articleRepository)
    private var articleRepository: ArticleRepository
    
    // MARK: - Publishers
    @Published
    var articles: [Article] = []
    
    @Published
    var user: User?
    
    init() {
        articleRepository.$articles
            .assign(to: &$articles)
        
        articleRepository.$user
            .assign(to: &$user)
        
        articleRepository.subscribe()
    }
    
    func toggleReadStatus(_ article: Article) {
        articleRepository.toggleReadStatus(article)
    }
    
    func delete(_ article: Article) {
        articleRepository.removeArticle(article)
    }
    
    func signOut() {
        let firebaseAuth = Auth.auth()
        do {
            try firebaseAuth.signOut()
        } catch let signOutError as NSError {
            articleRepository.logger.error("Error signing out: \(signOutError.localizedDescription)")
        }
    }
}

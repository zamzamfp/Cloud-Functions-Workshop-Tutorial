//
// ArticleMetadataService.swift
// ReadItLater
//
// Created by Peter Friese on 15.03.23.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import Foundation
import OpenGraph
import os

public struct ArticleMetadata {
    public var url: String?
    public var text: String?
    public var metaTitle: String?
    public var metaDescription: String?
    public var metaUrl: String?
    public var metaAuthor: String?
    public var metaImage: String?
    public var siteName: String?
}

public class ArticleMetadataService {
    private let logger = Logger(subsystem: "com.example.firebase.workshop.ReadItLater", category: "metadata")
    
    public func fetchLinkMetadata(url urlString: String) async -> ArticleMetadata {
        self.logger.debug("Fetching meta data using Open Graph")
        
        // This header makes sure we request the desktop website, which will prevent Medium from trying to display a "open this in the app" interstitial
        let headers = ["User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36"]
        var result = ArticleMetadata(url: urlString)
        guard let url = URL(string: urlString) else { return result }
        
        do {
            let og = try await OpenGraph.fetch(url: url, headers: headers)
            
            if let finalUrl = og[.url] {
                result.metaUrl = finalUrl
            }
            if let title = og[.title] {
                result.metaTitle = title
            }
            if let image = og[.image] {
                result.metaImage = image
            }
            if let image = og[.imageUrl] {
                result.metaImage = image
            }
            if let siteName = og[.siteName] {
                result.siteName = siteName
            }
            if let description = og[.description] {
                result.metaDescription = description
            }
            if let author = og[.bookAuthor] {
                result.metaAuthor = author
            }
        }
        catch {
            print(error)
        }
        
        return result
    }
    
}

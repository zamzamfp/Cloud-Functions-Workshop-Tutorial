//
// AddArticleViewModel.swift
// ReadItLater
//
// Created by Peter Friese on 15.03.23.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import SwiftUI
import Combine
import Factory

class AddArticleViewModel: ObservableObject {
    // MARK: - Public published properties
    @Published var url: String = ""
    @Published var author: String = ""
    @Published var siteName: String = ""
    @Published var title: String = ""
    @Published var notes: String = ""
    @Published var description: String = ""
    
    // MARK: - Private published properties
    @Published private var metadata: ArticleMetadata?
    
    // MARK: - Dependencies
    @Injected(\.articleRepository)
    private var repository
    
    @Injected(\.metadataService)
    private var metadataService
    
    init() {
        $url
            .asyncMap { await self.metadataService.fetchLinkMetadata(url: $0) }
            .receive(on: DispatchQueue.main)
            .assign(to: &$metadata)
        
        $metadata
            .compactMap { $0?.metaTitle }
            .filter { _ in self.title.isEmpty } // don't overwrite if title already contains a value
            .assign(to: &$title)
        
        $metadata
            .compactMap { $0?.siteName }
            .filter { _ in self.siteName.isEmpty } // don't overwrite if title already contains a value
            .assign(to: &$siteName)
        
        $metadata
            .compactMap { $0?.metaAuthor }
            .filter { _ in self.author.isEmpty } // don't overwrite if title already contains a value
            .assign(to: &$author)
        
        $metadata
            .compactMap { $0?.metaDescription }
            .filter { _ in self.description.isEmpty } // don't overwrite if title already contains a value
            .assign(to: &$description)
    }
    
    func addArticle() {
        let article = Article(title: title,
                              author: metadata?.metaAuthor ?? "",
                              readingTime: 0,
                              url: url,
                              imageUrl: metadata?.metaImage,
                              siteName: metadata?.siteName ?? "",
                              dateAdded: Date(),
                              excerpt: metadata?.metaDescription ?? "",
                              notes: notes)
        
        repository.addArticle(article)
    }
}


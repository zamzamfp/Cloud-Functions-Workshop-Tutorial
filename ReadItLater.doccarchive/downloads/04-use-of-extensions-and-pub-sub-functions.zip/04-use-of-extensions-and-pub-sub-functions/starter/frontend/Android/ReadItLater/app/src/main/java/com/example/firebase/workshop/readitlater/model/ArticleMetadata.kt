package com.example.firebase.workshop.readitlater.model

data class ArticleMetadata(
    val url: String?,
    val text: String?,
    val metaTitle: String?,
    val metaDescription: String?,
    val metaUrl: String?,
    val metaAuthor: String?,
    val metaImage: String?,
    val siteName: String?
)
package com.example.firebase.workshop.readitlater.screens.splash

import androidx.compose.runtime.mutableStateOf
import com.example.firebase.workshop.readitlater.ARTICLES_SCREEN
import com.example.firebase.workshop.readitlater.SPLASH_SCREEN
import com.example.firebase.workshop.readitlater.common.ReadItLaterViewModel
import com.example.firebase.workshop.readitlater.services.AccountService
import com.google.firebase.auth.FirebaseAuthException
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject


@HiltViewModel
class SplashViewModel @Inject constructor(
    private val accountService: AccountService,
) : ReadItLaterViewModel() {
    val showError = mutableStateOf(false)

    fun onAppStart(openAndPopUp: (String, String) -> Unit) {
        showError.value = false
        if (accountService.hasUser) openAndPopUp(ARTICLES_SCREEN, SPLASH_SCREEN)
        else createAnonymousAccount(openAndPopUp)
    }

    private fun createAnonymousAccount(openAndPopUp: (String, String) -> Unit) {
        launchCatching(snackbar = false) {
            try {
                accountService.createAnonymousAccount()
            } catch (ex: FirebaseAuthException) {
                showError.value = true
                throw ex
            }
            openAndPopUp(ARTICLES_SCREEN, SPLASH_SCREEN)
        }
    }
}

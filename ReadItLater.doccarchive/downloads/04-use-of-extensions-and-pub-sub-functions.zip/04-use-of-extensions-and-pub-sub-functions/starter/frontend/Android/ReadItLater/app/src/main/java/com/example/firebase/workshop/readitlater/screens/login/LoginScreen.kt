package com.example.firebase.workshop.readitlater.screens.login

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.firebase.workshop.readitlater.R
import com.example.firebase.workshop.readitlater.common.composable.BasicButton
import com.example.firebase.workshop.readitlater.common.composable.BasicTextButton
import com.example.firebase.workshop.readitlater.common.composable.BasicToolbar
import com.example.firebase.workshop.readitlater.common.composable.EmailField
import com.example.firebase.workshop.readitlater.common.composable.PasswordField
import com.example.firebase.workshop.readitlater.common.ext.basicButton
import com.example.firebase.workshop.readitlater.common.ext.fieldModifier
import com.example.firebase.workshop.readitlater.common.ext.textButton

@Composable
fun LoginScreen(
    openAndPopUp: (String, String) -> Unit,
    modifier: Modifier = Modifier,
    viewModel: LoginViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState

    BasicToolbar(R.string.login_details)

    Column(
        modifier = modifier.fillMaxWidth().fillMaxHeight().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        EmailField(uiState.email, viewModel::onEmailChange, Modifier.fieldModifier())
        PasswordField(uiState.password, viewModel::onPasswordChange, Modifier.fieldModifier())

        BasicButton(R.string.sign_in, Modifier.basicButton()) { viewModel.onSignInClick(openAndPopUp) }

        BasicTextButton(R.string.forgot_password, Modifier.textButton()) {
            viewModel.onForgotPasswordClick()
        }
    }
}

package com.example.firebase.workshop.readitlater.screens.settings

data class SettingsUIState(val isAnonymousAccount: Boolean = true)
package com.example.firebase.workshop.readitlater.services

interface ArticleSummaryService {
    suspend fun summariseURL(url: String): String
}
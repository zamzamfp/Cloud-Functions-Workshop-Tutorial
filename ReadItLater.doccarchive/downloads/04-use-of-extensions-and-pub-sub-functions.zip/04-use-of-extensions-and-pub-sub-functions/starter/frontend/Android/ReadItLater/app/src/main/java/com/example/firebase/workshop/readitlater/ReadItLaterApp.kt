package com.example.firebase.workshop.readitlater

import android.content.res.Resources
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.firebase.workshop.readitlater.screens.add.AddArticleScreen
import com.example.firebase.workshop.readitlater.screens.list.ArticlesScreen
import com.example.firebase.workshop.readitlater.screens.login.LoginScreen
import com.example.firebase.workshop.readitlater.screens.reader.ArticleReaderScreen
import com.example.firebase.workshop.readitlater.screens.settings.SettingsScreen
import com.example.firebase.workshop.readitlater.screens.signup.SignupScreen
import com.example.firebase.workshop.readitlater.screens.splash.SplashScreen
import com.example.firebase.workshop.readitlater.ui.theme.ReadItLaterTheme
import kotlinx.coroutines.CoroutineScope

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReadItLaterApp() {
    ReadItLaterTheme {
        Surface(color = MaterialTheme.colorScheme.background) {
            val appState = rememberAppState()

            Scaffold() { innerPaddingModifier ->
                NavHost(
                    navController = appState.navController,
                    startDestination = SPLASH_SCREEN,
                    modifier = Modifier.padding(innerPaddingModifier)
                ) {
                    readItLaterGraph(appState)
                }
            }
        }
    }
}

@Composable
fun rememberAppState(
    navController: NavHostController = rememberNavController(),
    resources: Resources = resources(),
    coroutineScope: CoroutineScope = rememberCoroutineScope()
) =
    remember(
        navController,
        resources,
        coroutineScope) {
        ReadItLaterAppState(
            navController,
            resources,
            coroutineScope)
    }

@Composable
@ReadOnlyComposable
fun resources(): Resources {
    return LocalContext.current.resources
}

fun NavGraphBuilder.readItLaterGraph(appState: ReadItLaterAppState) {
    composable(SPLASH_SCREEN) {
        SplashScreen(openAndPopUp = { route, popUp -> appState.navigateAndPopUp(route, popUp) })
    }

    composable(SETTINGS_SCREEN) {
        SettingsScreen(
            restartApp = { route -> appState.clearAndNavigate(route) },
            openScreen = { route -> appState.navigate(route) }
        )
    }

    composable(LOGIN_SCREEN) {
        LoginScreen(openAndPopUp = { route, popUp -> appState.navigateAndPopUp(route, popUp) })
    }

    composable(SIGN_UP_SCREEN) {
        SignupScreen(openAndPopUp = { route, popUp -> appState.navigateAndPopUp(route, popUp) })
    }

    composable(ARTICLES_SCREEN) {
        ArticlesScreen(openScreen = { route -> appState.navigate(route) })
    }

    composable(
        route = "$ADD_ARTICLE_SCREEN$ARTICLE_ID_ARG",
        arguments = listOf(navArgument(ARTICLE_ID) { defaultValue = ARTICLE_DEFAULT_ID })
    ) {
        AddArticleScreen(
            popUpScreen = { appState.popUp() },
            articleId = it.arguments?.getString(ARTICLE_ID)?.idFromParameter() ?: ARTICLE_DEFAULT_ID
        )
    }

    composable(
        route = "$READ_ARTICLE_SCREEN$ARTICLE_ID_ARG",
        arguments = listOf(navArgument(ARTICLE_ID) { defaultValue = ARTICLE_DEFAULT_ID })
    ) {
        ArticleReaderScreen(
            popUpScreen = { appState.popUp() },
            articleId = it.arguments?.getString(ARTICLE_ID)?.idFromParameter() ?: ARTICLE_DEFAULT_ID
        )
    }
}

fun String.idFromParameter(): String {
    return this.substring(1, this.length - 1)
}


# Project Files: Cloud Firestore Triggers

Cloud Function triggers allow you to run code in response to evens happening in the backend of your app, for example when your app creates a new Cloud Firestore document or modifies an existing one.

In this part of the [Supercharge your mobile apps with Cloud Functions for Firebase](https://github.com/peterfriese/Cloud-Functions-Workshop) tutorial, you will create a Cloud Function that will be triggered when the user adds a new article in the app. The function will then fetch the metadata of the article, and download a simplified version of the HTML of the article and store these back into the Firestore document. This allows the user to read the article offline, similar to Safari's _reader mode_.

The `starter` folder contains everything you need to follow along the tutorial:

* The initial version of the Cloud Function
* An iOS app that you can use to add new articles to Cloud Firestore
* An Android app that you can use to add new articles to Cloud Firestore

To explore on your own, open the respective project in the **final** folder and browse the project's code.

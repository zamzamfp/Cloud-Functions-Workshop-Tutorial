package com.example.firebase.workshop.readitlater.screens.list

import android.annotation.SuppressLint
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.firebase.workshop.readitlater.R
import com.example.firebase.workshop.readitlater.common.composable.ActionToolbar
import com.example.firebase.workshop.readitlater.common.ext.toolbarActions
import com.example.firebase.workshop.readitlater.model.Article
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun ArticlesScreen(
    openScreen: (String) -> Unit,
    viewModel: ArticlesScreenViewModel = hiltViewModel()
) {
    val coroutineScope = rememberCoroutineScope()
    var showAlert by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("Name") }
    var greeting by remember { mutableStateOf("Hello") }
    var showDialog by remember { mutableStateOf(false) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { viewModel.onAddArticleClick(openScreen) }) {
                Icon(Icons.Filled.Add, "Add")
            }
        },
        topBar = {
            ActionToolbar(
                title = R.string.articles,
                modifier = Modifier.toolbarActions(),
                endActionIcon = R.drawable.ic_settings,
                endAction = { showAlert = !showAlert }
            )
        }
    ) {
        val articles = viewModel.articles.collectAsState(initial = emptyList())
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 64.dp, bottom = 64.dp)

        ) {
            ArticleList(
                articles = articles,
                onItemClicked = {
                    viewModel.onReadArticleClick(openScreen, it)
                },
                modifier = Modifier.fillMaxSize()
            )
        }

        if (showAlert) {
            AlertDialog(
                onDismissRequest = { showAlert = false },
                title = { Text("Enter your name") },
                text = {
                    Column {
                        Text("Please enter your name:")
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it },
                            label = { Text("Name") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                greeting = viewModel.onGreetUser(name)
                                showAlert = false
                                showDialog = true
                            }
                        }
                    ) {
                        Text("Submit")
                    }
                },
                dismissButton = {
                    Button(
                        onClick = {
                            showAlert = false
                        }
                    ) {
                        Text("Cancel")
                    }
                }
            )
        }

        if (showDialog) {
            Dialog(
                onDismissRequest = { showDialog = false }
            ) {
                Text(greeting)
            }
        }
    }
}

@Composable
fun ArticleList(articles: State<List<Article>>, onItemClicked: (Article) -> Unit, modifier: Modifier = Modifier) {
    LazyColumn(modifier = modifier) {
        items(articles.value) {
            ArticleItem(article = it, onItemClicked = onItemClicked)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArticleItem(article: Article, onItemClicked: (Article) -> Unit) {
    Column {
        ListItem(
            headlineContent = { Text(article.title) },
            supportingContent = { Text(article.excerpt) },
            modifier = Modifier.clickable {
                onItemClicked(article)
            }
        )
        Divider()
    }
}


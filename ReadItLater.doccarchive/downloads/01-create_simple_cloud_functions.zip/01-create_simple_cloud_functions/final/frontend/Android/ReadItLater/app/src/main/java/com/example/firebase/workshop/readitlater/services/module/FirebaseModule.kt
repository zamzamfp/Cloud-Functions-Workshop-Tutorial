package com.example.firebase.workshop.readitlater.services.module

import android.util.Log
import com.example.firebase.workshop.readitlater.services.module.FirebaseModule.USE_EMULATOR
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.functions.ktx.functions
import com.google.firebase.ktx.Firebase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object FirebaseModule {
    private const val TAG = "FirebaseModule"
    private const val USE_EMULATOR = false

    @Singleton
    @Provides
    fun auth(): FirebaseAuth = Firebase.auth.apply {
        try {
            if (USE_EMULATOR) {
                useEmulator("10.0.2.2", 9099)
            }
        } catch (e: IllegalStateException) {
            Log.e(TAG, "User emulator failed", e)
        }
    }


    @Singleton
    @Provides
    fun firestore(): FirebaseFirestore = Firebase.firestore.apply {
        try {
            if (USE_EMULATOR) {
                useEmulator("10.0.2.2", 8080)
            }
        } catch (e: IllegalStateException) {
            Log.e(TAG, "User emulator failed", e)
        }
    }

    @Provides fun functions(): FirebaseFunctions = Firebase.functions("europe-west1").apply {
        try {
            if (USE_EMULATOR) {
                useEmulator("10.0.2.2", 5001)
            }
        } catch (e: IllegalStateException) {
            Log.e(TAG, "User emulator failed", e)
        }
    }
}

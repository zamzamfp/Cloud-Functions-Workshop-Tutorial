package com.example.firebase.workshop.readitlater.services.implementation

import com.example.firebase.workshop.readitlater.model.ArticleMetadata
import com.example.firebase.workshop.readitlater.services.GreetUserService
import com.example.firebase.workshop.readitlater.services.MetadataService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import javax.inject.Inject
import java.net.URL
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.decodeFromString


@Serializable
data class GreetResponse(val message: String)

class GreetUserServiceImpl @Inject constructor() : GreetUserService {
    override suspend fun getUserGreeting(name: String): String {
        return withContext(Dispatchers.IO) {
            val url = URL("// TODO: fill here with your endpoint url/greetUser?name=$name")
            val response = url.readText()
            val result = Json.decodeFromString<GreetResponse>(response)
            result.message
        }
    }
}
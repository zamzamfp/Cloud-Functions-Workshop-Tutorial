package com.example.firebase.workshop.readitlater.services.implementation

import com.example.firebase.workshop.readitlater.services.ArticleSummaryService
import com.google.firebase.functions.FirebaseFunctions
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

class ArticleSummaryServiceImpl @Inject constructor(
    // TODO: (1) inject Cloud Functions
    private val functions: FirebaseFunctions,
) : ArticleSummaryService {

    override suspend fun summariseURL(url: String): String {
        // TODO: (2) call HTTPS Callable Function "summariseURLCallable"
        return "TODO"
    }
}

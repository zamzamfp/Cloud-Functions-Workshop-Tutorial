package com.example.firebase.workshop.readitlater.services

import com.example.firebase.workshop.readitlater.model.ArticleMetadata

interface GreetUserService {
    suspend fun getUserGreeting(name: String): String
}


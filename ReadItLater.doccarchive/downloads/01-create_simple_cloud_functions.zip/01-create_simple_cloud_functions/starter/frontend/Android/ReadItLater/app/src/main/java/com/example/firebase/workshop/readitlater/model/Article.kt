package com.example.firebase.workshop.readitlater.model

import com.google.firebase.firestore.DocumentId

data class Article(
    @DocumentId val id: String = "",
    val url: String = "",
    val title: String = "",
    val excerpt: String = "",
    val notes: String = "",
    val readableHTML: String = "",
    val userId: String = ""
)
package com.example.firebase.workshop.readitlater.screens.login

data class LoginUIState(
    val email: String = "",
    val password: String = ""
)

package com.example.firebase.workshop.readitlater.services.implementation

import com.example.firebase.workshop.readitlater.services.GreetUserService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import java.net.URL
import javax.inject.Inject


@Serializable
data class GreetResponse(val message: String)

class GreetUserServiceImpl @Inject constructor() : GreetUserService {
    override suspend fun getUserGreeting(name: String): String {
        return withContext(Dispatchers.IO) {
            val url = URL("https://us-central1-cloud-functions-staging-edb80.cloudfunctions.net/greetUser?name=$name")
            val response = url.readText()
            val result = Json.decodeFromString<GreetResponse>(response)
            result.message
        }
    }
}
package com.example.firebase.workshop.readitlater

const val SPLASH_SCREEN = "SplashScreen"

const val ARTICLES_SCREEN = "ArticlesScreen"
const val ADD_ARTICLE_SCREEN = "AddArticleScreen"
const val READ_ARTICLE_SCREEN = "ArticleReaderScreen"

const val ARTICLE_ID = "articleId"
const val ARTICLE_DEFAULT_ID = "-1"
const val ARTICLE_ID_ARG = "?$ARTICLE_ID={$ARTICLE_ID}"

const val SETTINGS_SCREEN = "SettingsScreen"
const val SIGN_UP_SCREEN = "SignupScreen"
const val LOGIN_SCREEN = "LoginScreen"
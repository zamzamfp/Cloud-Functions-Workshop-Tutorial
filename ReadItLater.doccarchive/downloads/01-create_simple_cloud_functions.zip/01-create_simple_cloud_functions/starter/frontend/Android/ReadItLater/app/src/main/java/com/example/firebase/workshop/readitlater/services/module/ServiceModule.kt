package com.example.firebase.workshop.readitlater.services.module

import com.example.firebase.workshop.readitlater.services.AccountService
import com.example.firebase.workshop.readitlater.services.ArticleSummaryService
import com.example.firebase.workshop.readitlater.services.GreetUserService
import com.example.firebase.workshop.readitlater.services.MetadataService
import com.example.firebase.workshop.readitlater.services.StorageService
import com.example.firebase.workshop.readitlater.services.implementation.AccountServiceImpl
import com.example.firebase.workshop.readitlater.services.implementation.ArticleSummaryServiceImpl
import com.example.firebase.workshop.readitlater.services.implementation.GreetUserServiceImpl
import com.example.firebase.workshop.readitlater.services.implementation.MetadataServiceImpl
import com.example.firebase.workshop.readitlater.services.implementation.StorageServiceImpl
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
abstract class ServiceModule {
    @Binds abstract fun provideAccountService(impl: AccountServiceImpl): AccountService

    @Binds abstract fun provideStorageService(impl: StorageServiceImpl): StorageService

    @Binds abstract fun provideMetadataService(impl: MetadataServiceImpl): MetadataService

    @Binds abstract fun provideArticleSummaryService(impl: ArticleSummaryServiceImpl): ArticleSummaryService

    @Binds abstract fun provideGreetUserService(impl: GreetUserServiceImpl): GreetUserService
}

package com.example.firebase.workshop.readitlater.services

import com.example.firebase.workshop.readitlater.model.Article
import kotlinx.coroutines.flow.Flow

interface StorageService {
    val articles: Flow<List<Article>>

    suspend fun getArticle(articleId: String): Article?
    suspend fun save(article: Article)
    suspend fun update(article: Article)
    suspend fun delete(articleId: String)
}

package com.example.firebase.workshop.readitlater.screens.add

import com.example.firebase.workshop.readitlater.ARTICLE_DEFAULT_ID
import com.example.firebase.workshop.readitlater.common.ReadItLaterViewModel
import com.example.firebase.workshop.readitlater.model.Article
import com.example.firebase.workshop.readitlater.services.ArticleSummaryService
import com.example.firebase.workshop.readitlater.services.MetadataService
import com.example.firebase.workshop.readitlater.services.StorageService
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import javax.inject.Inject

@HiltViewModel
class AddArticleScreenViewModel @Inject constructor(
    private val storageService: StorageService,
    private val metadataService: MetadataService,
    private val summaryService: ArticleSummaryService
) : ReadItLaterViewModel() {

    private val _article = MutableStateFlow(Article())
    val article: StateFlow<Article> = _article.asStateFlow()

    fun initialize(articleId: String) {
        launchCatching {
            if (articleId != ARTICLE_DEFAULT_ID) {
                _article.value = storageService.getArticle(articleId) ?: Article()
            }
        }
    }

    fun onURLChange(newValue: String) {
        _article.update { it.copy(url = newValue) }
        fetchMetadata(newValue)
    }

    fun onTitleChange(newValue: String) {
        _article.update { it.copy(title = newValue) }
    }

    fun onDescriptionChange(newValue: String) {
        _article.update { it.copy(excerpt = newValue) }
    }

    fun onNotesChange(newValue: String) {
        _article.update { it.copy(notes = newValue) }
    }

    fun onDoneClick(popUpScreen: () -> Unit) {
        launchCatching {
            val editedArticle = article.value
            if (editedArticle.id.isBlank()) {
                storageService.save(editedArticle)
            } else {
                storageService.update(editedArticle)
            }
            popUpScreen()
        }
    }

    private fun fetchMetadata(url: String) {
        launchCatching {
            val metadata = metadataService.getMetadata(url)

            metadata.metaDescription?.let { description ->
                _article.update { it.copy(excerpt = description) }
            }

            metadata.metaTitle?.let { title ->
                _article.update { it.copy(title = title) }
            }

        }
    }
}
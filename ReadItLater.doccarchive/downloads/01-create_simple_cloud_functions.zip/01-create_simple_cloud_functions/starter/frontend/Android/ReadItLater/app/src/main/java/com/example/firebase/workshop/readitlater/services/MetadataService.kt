package com.example.firebase.workshop.readitlater.services

import com.example.firebase.workshop.readitlater.model.ArticleMetadata

interface MetadataService {
    suspend fun getMetadata(url: String): ArticleMetadata
}
package com.example.firebase.workshop.readitlater.services

interface GreetUserService {
    suspend fun getUserGreeting(name: String): String
}


//
// ArticleVIew.swift
// ReadItLater
//
// Created by Peter Friese on 15.03.23.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import SwiftUI
import WebView
import Combine
import Factory

@MainActor
class ArticleViewModel: ObservableObject {
    // MARK: - Dependencies
    @Injected(\.articleRepository)
    private var articleRepository: ArticleRepository
    
    @Injected(\.summaryService)
    private var articleSummariser
    
    // MARK: - Published properties
    @Published
    var articleNote: String = ""
    
    @Published
    var isSummarising = false
    
    // MARK: - Private attributes
    
    func toggleReadStatus(_ article: Article) {
        articleRepository.toggleReadStatus(article)
    }
    
    func delete(_ article: Article) {
        articleRepository.removeArticle(article)
    }
    
    func summarise(_ article: Article) {
        Task {
            isSummarising = true
            let summary = await articleSummariser.summariseURL(url: article.url)
            articleNote = [summary, articleNote].joined(separator: "\n\n")
            isSummarising = false
        }
    }
    
    func updateNotes(for article: Article) {
        var editableArticle = article
        editableArticle.notes = articleNote
        articleRepository.updateArticle(editableArticle)
    }
}

struct ArticleView: View {
    var article: Article
    
    @StateObject
    private var webViewStore = WebViewStore()
    
    @ObservedObject
    private var viewModel = ArticleViewModel()
    
    @State
    private var isNoteSheetPresented = false
    
    private func doneTapped() {
        viewModel.updateNotes(for: article)
        isNoteSheetPresented.toggle()
    }
    
    init(article: Article) {
        self.article = article
        viewModel.articleNote = article.notes ?? ""
    }
    
    var body: some View {
        VStack {
            WebView(webView: webViewStore.webView)
                .onAppear {
                    if let url = URL(string: article.url) {
                        webViewStore.webView.loadHTMLString(article.wrappedHTML, baseURL: url)
                    }
                    viewModel.articleNote = article.notes ?? ""
                }
                .onChange(of: article) { article in
                    if let url = URL(string: article.url) {
                        webViewStore.webView.loadHTMLString(article.wrappedHTML, baseURL: url)
                    }
                    viewModel.articleNote = article.notes ?? ""
                }
                .toolbar {
                    ToolbarItemGroup(placement: .bottomBar) {
                        Spacer()
                        Divider().frame(width: 1, height: 20)
                            .background(.tint)
                        Spacer()
                        Button(action: {}) {
                            Image(systemName: "tag")
                        }
                        Spacer()
                        Button(action: { isNoteSheetPresented.toggle() }) {
                            Image(systemName: "note.text")
                        }
                        Spacer()
                        Button(action: { }) {
                            Image(systemName: "ellipsis.circle")
                        }
                    }
                }
                .sheet(isPresented: $isNoteSheetPresented) {
                    NavigationStack {
                        Divider()
                            .frame(height: 1)
                        TextEditor(text: $viewModel.articleNote)
                            .padding(8)
                            .navigationTitle("Notes")
                            .navigationBarTitleDisplayMode(.inline)
                            .toolbar {
                                ToolbarItem(placement: .confirmationAction) {
                                    Button(action: doneTapped) {
                                        Text("Done")
                                    }
                                }
                                ToolbarItem(placement: .cancellationAction) {
                                    Button(action: { viewModel.summarise(article)} ) {
                                        if viewModel.isSummarising {
                                            ProgressView()
                                                .progressViewStyle(CircularProgressViewStyle())
                                        }
                                        else {
                                            Image(systemName: "wand.and.stars")
                                        }
                                    }
                                }
                            }
                    }
                    .presentationDetents([.medium, .fraction(0.4)])
                }
        }
        .padding(.horizontal, 16)
    }
}

struct ArticleView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            ArticleView(article: Article.samples[0])
        }
    }
}

//
// ContentView.swift
// ReadItLater
//
// Created by Peter Friese on 15.03.23.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import SwiftUI
import FirebaseAuth

struct ArticlesListView: View {
    @StateObject
    private var viewModel = ArticlesListViewModel()
    
    @State
    private var isAddArticleDialogPresented = false
    
    private func presentAddArticleDialog() {
        isAddArticleDialogPresented.toggle()
    }
    
    @State
    private var isSettingsScreenPresented = false
    
    @State
    private var showingAlert = false
    
    @State
    private var name = ""

    private func presentSettingsScreen() {
        isSettingsScreenPresented.toggle()
    }
    
    private func showGreetUserAlert() {
        showingAlert.toggle()
    }
        
    var body: some View {
        if !(viewModel.greeting?.isEmpty ?? true) {
            Text(viewModel.greeting ?? "")
        }
        List(viewModel.articles) { article in
            NavigationLink(value: article) {
                ArticleListRowView(article: article)
                    .swipeActions(edge: .leading, allowsFullSwipe: true) {
                        Button (action: { viewModel.toggleReadStatus(article) }) {
                            Label {
                                article.isRead ?? false ? Text("Unread") : Text("Read")
                            } icon: {
                                article.isRead ?? false ? Image(systemName: "circlebadge") : Image(systemName: "checkmark.circle")
                            }
                        }
                        .tint(.blue)
                    }
                    .swipeActions(edge: .trailing) {
                        Button(role: .destructive, action: { viewModel.delete(article)} ) {
                            Label("Delete", systemImage: "trash")
                        }
                    }
            }
        }
        .navigationDestination(for: Article.self, destination: { article in
            ArticleView(article: article)
        })
        .listStyle(.plain)
        .navigationTitle("Articles")
        .toolbar {
            ToolbarItem(placement: .confirmationAction) {
                Button(action: showGreetUserAlert) {
                    Image(systemName: "hand.wave")
                }
            }
            
            ToolbarItem(placement: .confirmationAction) {
                Button(action: presentSettingsScreen) {
                    Image(systemName: "gearshape")
                }
            }
            
            ToolbarItem(placement: .bottomBar) {
                Spacer()
            }
            
            ToolbarItem(placement: .bottomBar) {
                Button(action: presentAddArticleDialog) {
                    Image(systemName: "plus")
                }
            }
        }
        .sheet(isPresented: $isAddArticleDialogPresented) {
            AddArticleView()
        }
        .sheet(isPresented: $isSettingsScreenPresented) {
            SettingsView()
        }
        .alert("Enter your name", isPresented: $showingAlert) {
            TextField("Enter your name", text: $name)
            Button {
                Task {
                    await viewModel.callGreetUserFunction(name: name)
                }
            } label: {
                Text("Send")
            }
        } message: {
            Text("Greet User")
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            ArticlesListView()
        }
    }
}
